import copy
import math
from typing import Dict, List, Tuple
import torch
from torch import Tensor, nn
from torch.nn import functional as F
from torchvision.ops import boxes as box_ops

from models.bricks.denoising import GenerateCDNQueries
from models.bricks.losses import sigmoid_focal_loss
from models.detectors.base_detector import DNDETRDetector
from models.bricks.saliency import AdaptiveSaliencyBlock
from models.bricks.background_suppression import BackgroundSuppressionGate
from models.bricks.adaptive_multiscale_fusion import AdaptiveMultiScaleFusion

class PositionCriterion(nn.Module):
    def __init__(
        self,
        limit_range: Tuple = ((-1, 64), (64, 128), (128, 256), (256, 99999)),
        noise_scale: float = 0.0,
        alpha: float = 0.25,
        gamma: float = 2.0,
    ):
        super().__init__()
        self.limit_range = limit_range
        self.noise_scale = noise_scale
        self.alpha = alpha
        self.gamma = gamma

    def forward(self, foreground_mask, targets, feature_strides, image_sizes):
        gt_boxes_list = []
        for t, (img_h, img_w) in zip(targets, image_sizes):
            boxes = t["boxes"]
            boxes = box_ops._box_cxcywh_to_xyxy(boxes)
            scale_factor = torch.tensor([img_w, img_h, img_w, img_h], device=boxes.device)
            gt_boxes_list.append(boxes * scale_factor)

        mask_targets = []
        for level_idx, (mask, feature_stride) in enumerate(zip(foreground_mask, feature_strides)):
            feature_shape = mask.shape[-2:]
            coord_x, coord_y = self.get_pixel_coordinate(feature_shape, feature_stride, device=mask.device)
            masks_per_level = []
            for gt_boxes in gt_boxes_list:
                mask = self.get_mask_single_level(coord_x, coord_y, gt_boxes, level_idx)
                masks_per_level.append(mask)

            masks_per_level = torch.stack(masks_per_level)
            mask_targets.append(masks_per_level)
        mask_targets = torch.cat(mask_targets, dim=1)
        foreground_mask = torch.cat([e.flatten(-2) for e in foreground_mask], -1)
        foreground_mask = foreground_mask.squeeze(1)
        num_pos = torch.sum(mask_targets > 0.5 * self.noise_scale).clamp_(min=1)
        position_loss = (
            sigmoid_focal_loss(
                foreground_mask,
                mask_targets,
                num_pos,
                alpha=self.alpha,
                gamma=self.gamma,
            ) * foreground_mask.shape[1]
        )
        return {"loss_position": position_loss}
    def get_pixel_coordinate(self, feature_shape, stride, device):
        height, width = feature_shape
        coord_y, coord_x = torch.meshgrid(
            torch.linspace(0.5, height - 0.5, height, dtype=torch.float32, device=device) * stride[0],
            torch.linspace(0.5, width - 0.5, width, dtype=torch.float32, device=device) * stride[1],
            indexing="ij",
        )
        coord_y = coord_y.reshape(-1)
        coord_x = coord_x.reshape(-1)
        return coord_x, coord_y

    def get_mask_single_level(self, coord_x, coord_y, gt_boxes, level_idx):
        # gt_label: (m,) gt_boxes: (m, 4)
        # coord_x: (h*w, )
        left_border_distance = coord_x[:, None] - gt_boxes[None, :, 0]  # (h*w, m)
        top_border_distance = coord_y[:, None] - gt_boxes[None, :, 1]
        right_border_distance = gt_boxes[None, :, 2] - coord_x[:, None]
        bottom_border_distance = gt_boxes[None, :, 3] - coord_y[:, None]
        border_distances = torch.stack(
            [left_border_distance, top_border_distance, right_border_distance, bottom_border_distance],
            dim=-1,
        )  # [h*w, m, 4]

        min_border_distances = torch.min(border_distances, dim=-1)[0]  # [h*w, m]
        max_border_distances = torch.max(border_distances, dim=-1)[0]
        mask_in_gt_boxes = min_border_distances > 0
        min_limit, max_limit = self.limit_range[level_idx]
        mask_in_level = (max_border_distances > min_limit) & (max_border_distances <= max_limit)
        mask_pos = mask_in_gt_boxes & mask_in_level

        # scale-independent position confidence
        row_factor = left_border_distance + right_border_distance
        col_factor = top_border_distance + bottom_border_distance
        delta_x = (left_border_distance - right_border_distance) / row_factor
        delta_y = (top_border_distance - bottom_border_distance) / col_factor
        confidence = torch.sqrt(delta_x**2 + delta_y**2) / 2

        confidence_per_box = (1 - torch.tanh(2 * math.pi * confidence - math.pi)) / 2
        confidence_per_box[~mask_in_gt_boxes] = 0

        # process positive coordinates
        if confidence_per_box.numel() != 0:
            mask = confidence_per_box.max(-1)[0]
        else:
            mask = torch.zeros(coord_y.shape, device=confidence.device, dtype=confidence.dtype)

        # process negative coordinates
        mask_pos = mask_pos.long().sum(dim=-1) >= 1
        mask[~mask_pos] = 0

        # add noise to add randomness
        mask = (1 - self.noise_scale) * mask + self.noise_scale * torch.rand_like(mask)
        return mask

class PositionDETR(DNDETRDetector):
    def __init__(
        # model structure
        self,
        backbone: nn.Module,
        neck: nn.Module,
        position_embedding: nn.Module,
        transformer: nn.Module,
        criterion: nn.Module,
        postprocessor: nn.Module,
        focus_criterion: nn.Module,
        # model parameters
        num_classes: int,
        num_queries: int = 900,
        hybrid_assign: int = 6,
        denoising_nums: int = 100,
        # model variants
        aux_loss: bool = True,
        min_size: int = None,
        max_size: int = None,
        v3_variant: str = "none",
    ):
        super().__init__(min_size, max_size)
        # define model parameters
        self.num_classes = num_classes
        self.aux_loss = aux_loss
        embed_dim = transformer.embed_dim
        self.hybrid_assign = hybrid_assign

        # define model structures
        self.backbone = backbone
        self.neck = neck
        self.position_embedding = position_embedding
        self.transformer = transformer
        self.criterion = criterion
        self.postprocessor = postprocessor
        self.denoising_generator = GenerateCDNQueries(
            num_queries=num_queries,
            num_classes=num_classes,
            label_embed_dim=embed_dim,
            denoising_nums=denoising_nums,
            label_noise_prob=0.5,
            box_noise_scale=1.0,
        )
        self.focus_criterion = focus_criterion

        # ======================================================
        # Adaptive Saliency Enhancement
        # ======================================================

        valid_v3_variants = {"none", "a", "b", "c"}
        v3_variant = v3_variant.lower()
        if v3_variant not in valid_v3_variants:
            raise ValueError(
                f"v3_variant must be one of {sorted(valid_v3_variants)}, "
                f"received {v3_variant!r}"
            )

        if len(self.neck.num_channels) < 3:
            raise ValueError(
                "v3 experiments require at least three neck feature levels "
                "[P2, P3, P4]."
            )

        self.v3_variant = v3_variant

        # Keep Adaptive Saliency v2 as the common base for all runs.
        # Apply it only to P2 and P3 to avoid strengthening high-level
        # large-object features unnecessarily.
        self.saliency = nn.ModuleList(
            [
                AdaptiveSaliencyBlock(self.neck.num_channels[0]),  # P2
                AdaptiveSaliencyBlock(self.neck.num_channels[1]),  # P3
            ]
        )

        # v3-A and v3-C: background suppression on P2 and P3.
        if self.v3_variant in {"a", "c"}:
            self.background_suppression = nn.ModuleList(
                [
                    BackgroundSuppressionGate(
                        self.neck.num_channels[0],
                        gamma_init=0.01,
                    ),
                    BackgroundSuppressionGate(
                        self.neck.num_channels[1],
                        gamma_init=0.01,
                    ),
                ]
            )
        else:
            self.background_suppression = None

        # v3-B and v3-C: fuse P2 + P3 + P4 into P3.
        if self.v3_variant in {"b", "c"}:
            self.multiscale_fusion = AdaptiveMultiScaleFusion(
                in_channels=self.neck.num_channels[:3],
                target_index=1,
                gamma_init=0.01,
            )
        else:
            self.multiscale_fusion = None

    def forward(self, images: List[Tensor], targets: List[Dict] = None):
        # get original image sizes, used for postprocess
        original_image_sizes = self.query_original_sizes(images) 
        images, targets, mask = self.preprocess(images, targets) 

        # extract features
        multi_level_feats = self.backbone(images.tensors) 
        multi_level_feats = self.neck(multi_level_feats)

        # ======================================================
# Adaptive Saliency Enhancement
# ======================================================

        # Common base: Adaptive Saliency v2 on P2 and P3 only.
        multi_level_feats = list(multi_level_feats)
        multi_level_feats[0] = self.saliency[0](multi_level_feats[0])
        multi_level_feats[1] = self.saliency[1](multi_level_feats[1])

        # v3-A / v3-C: suppress background responses on P2 and P3.
        if self.background_suppression is not None:
            multi_level_feats[0] = self.background_suppression[0](
                multi_level_feats[0]
            )
            multi_level_feats[1] = self.background_suppression[1](
                multi_level_feats[1]
            )

        # v3-B / v3-C: replace P3 with fused P2 + P3 + P4.
        if self.multiscale_fusion is not None:
            multi_level_feats[1] = self.multiscale_fusion(
                multi_level_feats[:3]
            )

        multi_level_masks = [] 
        multi_level_pos_embeds = [] 
        for feature in multi_level_feats:
            multi_level_masks.append(F.interpolate(mask[None], size=feature.shape[-2:]).to(torch.bool)[0])
            multi_level_pos_embeds.append(self.position_embedding(multi_level_masks[-1]))

        if self.training:
            # collect ground truth for denoising generation
            gt_labels_list = [t["labels"] for t in targets]
            gt_boxes_list = [t["boxes"] for t in targets]
            noised_results = self.denoising_generator(gt_labels_list, gt_boxes_list)
            noised_label_queries = noised_results[0]
            noised_box_queries = noised_results[1]
            attn_mask = noised_results[2]
            denoising_groups = noised_results[3]
            max_gt_num_per_image = noised_results[4]
        else:
            noised_label_queries = None
            noised_box_queries = None
            attn_mask = None
            denoising_groups = None
            max_gt_num_per_image = None

        # feed into transformer
        (
            outputs_class,
            outputs_coord,
            enc_class,
            enc_coord,
            foreground_mask,
            hybrid_class,
            hybrid_coord,
            hybrid_enc_class,
            hybrid_enc_coord,
        ) = self.transformer(
            multi_level_feats,
            multi_level_masks,
            multi_level_pos_embeds,
            noised_label_queries,
            noised_box_queries,
            attn_mask=attn_mask,
        )

        # hack implemantation for distributed training
        outputs_class[0] += self.denoising_generator.label_encoder.weight[0, 0] * 0.0

        # denoising postprocessing
        if denoising_groups is not None and max_gt_num_per_image is not None:
            dn_metas = {
                "denoising_groups": denoising_groups,
                "max_gt_num_per_image": max_gt_num_per_image
            }
            outputs_class, outputs_coord = self.dn_post_process(
                outputs_class, outputs_coord, dn_metas
            )

        # prepare for loss computation
        output = {"pred_logits": outputs_class[-1], "pred_boxes": outputs_coord[-1]}
        output["aux_outputs"] = self._set_aux_loss(outputs_class, outputs_coord)
        output["enc_outputs"] = {"pred_logits": enc_class, "pred_boxes": enc_coord}

        if self.training:
            # prepare for hybrid loss computation
            hybrid_metas = {"pred_logits": hybrid_class[-1], "pred_boxes": hybrid_coord[-1]}
            hybrid_metas["aux_outputs"] = self._set_aux_loss(hybrid_class, hybrid_coord)
            hybrid_metas["enc_outputs"] = {
                "pred_logits": hybrid_enc_class,
                "pred_boxes": hybrid_enc_coord
            }

            # compute loss
            loss_dict = self.criterion(output, targets)
            dn_losses = self.compute_dn_loss(dn_metas, targets)
            loss_dict.update(dn_losses)
            # compute focus loss
            feature_stride = [(
                images.tensors.shape[-2] / feature.shape[-2],
                images.tensors.shape[-1] / feature.shape[-1],
            ) for feature in multi_level_feats]
            focus_loss = self.focus_criterion(foreground_mask, targets, feature_stride, images.image_sizes)
            loss_dict.update(focus_loss)
            # compute hybrid loss
            multi_targets = copy.deepcopy(targets)
            for t in multi_targets:
                t["boxes"] = t["boxes"].repeat(self.hybrid_assign, 1)
                t["labels"] = t["labels"].repeat(self.hybrid_assign)
            hybrid_losses = self.criterion(hybrid_metas, multi_targets)
            loss_dict.update({k + "_hybrid": v for k, v in hybrid_losses.items()})

            # loss reweighting
            weight_dict = self.criterion.weight_dict
            loss_dict = dict((k, loss_dict[k] * weight_dict[k])
                             for k in loss_dict.keys()
                             if k in weight_dict)
            return loss_dict

        detections = self.postprocessor(output, original_image_sizes)
        return detections
